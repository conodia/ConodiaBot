import 'package:mineral/core/api.dart';

import '../../../managers/cache_manager.dart';

class UsersCache extends CacheManager<Snowflake> {}