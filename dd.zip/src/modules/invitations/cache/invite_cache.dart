import '../../../managers/cache_manager.dart';
import '../managers/invite_manager.dart';

class InvitePandaCache extends CacheManager<InviteManager> {}