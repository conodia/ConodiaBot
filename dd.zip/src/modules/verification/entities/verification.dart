class Verification {
  String code;
  String userId;

  Verification(this.userId, this.code);
}