class Utils {
  static void printError(String text) {
    print('\x1B[31m$text\x1B[0m');
  }
}